import web from "../src/images/s1.jpg";
import app from "../src/images/app.jpeg";
import android from "../src/images/android.jpeg";
import marketing from "../src/images/marketing.jpg";
import software from "../src/images/software.jpeg";
import digital from "../src/images/digital.jpeg"

const Sdata=[
    {
        imgsrc:web,
        title:"Web Development"
    },
    {
        imgsrc:app,
        title:"App Development"
    },
    {
        imgsrc:android,
        title:"Android Development"
    },
    {
        imgsrc:marketing,
        title:"Marketing"
    },
    {
        imgsrc:software,
        title:"Software Development"
    },
    {
        imgsrc:digital,
        title:"Digital Marketing"
    },
];
export default Sdata;