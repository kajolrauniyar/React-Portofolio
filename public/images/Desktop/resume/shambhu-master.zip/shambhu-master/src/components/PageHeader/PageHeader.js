
import React from "react";
// reactstrap components
import { Container } from "reactstrap";

class PageHeader extends React.Component {
  render() {
    return (
      <div className="page-header header-filter">
        <div className="squares square1" />
        <div className="squares square2" />
        <div className="squares square3" />
        <div className="squares square4" />
        <div className="squares square5" />
        <div className="squares square6" />
        <div className="squares square7" />
        <Container>
          {/* TO DO - CHECK THE RESPONSIVENESS */}
          <div className="content-center brand">
            <h1 className="h1-seo">7992209964</h1>
            <h3 className="d-none d-sm-block">
            • नौकरी की तलाश है ? • हमसे संपर्क करें 
            </h3>
            <p>
              <a href="https://api.whatsapp.com/send?phone=917992209964&text=Welcome to Rojgar!!">
                <img
                    src={require("assets/img/whatsapp-button.png")}
                    style={{ width: "250px" }}                  
                  />
                </a>
            </p>
          </div>
        </Container>
      </div>
    );
  }
}

export default PageHeader;
