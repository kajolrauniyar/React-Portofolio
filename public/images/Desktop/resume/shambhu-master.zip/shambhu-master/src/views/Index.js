import React from "react";

// core components
import IndexNavbar from "components/Navbars/IndexNavbar.js";
import Footer from "components/Footer/Footer.js";

// sections for this page/view
import Home from "views/IndexSections/Home.jsx";
import Employee from "views/IndexSections/Employee.jsx";
import Employer from "views/IndexSections/Employer.jsx";
import Touch from "views/IndexSections/Touch.jsx";

class Index extends React.Component {
  componentDidMount() {
    document.body.classList.toggle("index-page");
  }
  componentWillUnmount() {
    document.body.classList.toggle("index-page");
  }
  render() {
    return (
      <>
        <IndexNavbar />
        <div className="wrapper">
          <Home />
          <div className="main">
            <Employee />
            <Employer />
            <Touch />
          </div>
          <Footer />
        </div>
      </>
    );
  }
}

export default Index;
